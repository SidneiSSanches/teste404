package com.carango.bom;


class CarangoBomApplicationTests {

	void contextLoads() {
	}

}
