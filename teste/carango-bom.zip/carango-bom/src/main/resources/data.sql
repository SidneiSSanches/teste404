 insert  into user_entity (login, password) values ('AlanPaiva', '$2a$10$jkXxJkzyX0.ou.ySo4wNq.OMp6aqMjp8x9Tq.gOKYVouFi.SB2fv.' ); 
 insert  into user_entity (login, password) values ('SamuelS', '$2a$10$IDzQc7M.RbK4stTWcY1fputiYA5Ks4lH9ocunsTx7DnXZMU7darnu'   ); 
 insert  into user_entity (login, password) values ('SidneiS', '$2a$10$DCt5JzNrwQl47ILyCcnG7uCHN4Hrcn4wA3SPT7fFmHVkEM.Ye/5XK'   ); 
 insert  into user_entity (login, password) values ('ThiagoH', '$2a$10$sweCAnjAXlz/CmbHSujrOO8.Kw9SBowEr2xhd.knxu7aBiP8j5xNq'   ); 
 insert  into user_entity (login, password) values ('TiagoG', '$2a$10$gdxXqRnkUSyosZvXllw.Cu8Vl7ybj4NgQ4WKErRwqK7mUnFAvFejm'    ); 
 insert  into user_entity (login, password) values ('WiliamN', '$2a$10$O.LkaT2c2lGmTy9H2zpdEuwecqaXWoVmoAmnDJkIbH/L5rSeBhcl2'   );

  

